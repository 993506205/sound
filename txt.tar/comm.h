// header file for communicatoin module

#define COMM
#define URL "http://www.cc.puv.fi/~gc/php/raspsound.php"

// function prototype
void send_data(double []);
